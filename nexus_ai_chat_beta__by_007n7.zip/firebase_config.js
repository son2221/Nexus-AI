// Firebase configuration for WebSim project
const firebaseConfig = {
  apiKey: "AIzaSyDu9_KQt4-8YZC9UMU7nfYrkcPeWpv4Hn0",
  authDomain: "websim-52be0.firebaseapp.com",
  projectId: "websim-52be0",
  storageBucket: "websim-52be0.appspot.com",
  messagingSenderId: "383820855135",
  appId: "1:383820855135:web:48ae31a2b29a84b55d9f02"
};

export default firebaseConfig;

